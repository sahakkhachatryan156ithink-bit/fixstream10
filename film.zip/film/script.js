console.log("Classic Cinema Loaded");

document.querySelectorAll(".movie").forEach(card=>{
    card.addEventListener("mouseenter",()=>{
        card.style.transform="scale(1.02)";
        card.style.transition="0.3s";
    });

    card.addEventListener("mouseleave",()=>{
        card.style.transform="scale(1)";
    });
});
const input = document.getElementById("searchInput");
const movies = document.querySelectorAll(".movie");

input.addEventListener("keyup", function () {
    const value = input.value.toLowerCase();

    movies.forEach(movie => {
        const title = movie.querySelector("h3").innerText.toLowerCase();

        if (title.includes(value)) {
            movie.style.display = "block";
        } else {
            movie.style.display = "none";
        }
    });
});